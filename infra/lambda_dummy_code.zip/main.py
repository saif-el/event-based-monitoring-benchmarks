import sys

from database_functionalities import constants
from database_functionalities import operation_handler


def main(operation):
    """
    This is the main function which is called when the package in run.
    it takes the operation name which is to be run.
    valid operations:
    1) add_workflow

    PARAMETERS
    ----------
    operation : Dict
        this dictionary contains the operation type and the arguments
        for it.
    """
    opr = operation[constants.OPERATION]
    if operation[constants.OPERATION]:
        operation[constants.ARGS] = {"file_name": operation["args"]}
        file_name = operation[constants.ARGS]["file_name"]
    else:
        print constants.USAGE_MESSAGE
        sys.exit()

    operations = define_operation()
    try:
        operations[opr](file_name)
    except KeyError as error:
        print "Invalid Operation :" + error.message
        usage = constants.USAGE_MESSAGE
        print usage


def define_operation():
    """
    This functions defines the various functions which the package
    provides. Avaiable operations:
        1) add_workflow : to add a new workflow
        2) add_metadata : to add metadata
    """
    oprs = dict()
    oprs[constants.OPR_ADD_WF] = operation_handler.add_workflow
    oprs[constants.OPR_ADD_METADATA] = operation_handler.add_metadata
    return oprs


if __name__ == '__main__':
    main({constants.OPERATION: sys.argv[1], constants.ARGS: sys.argv[2]})
